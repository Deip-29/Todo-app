import { useState } from 'react'
import Header from './components/Header'
import ToDoList from './components/ToDoList'
import './styles/App.css'

// Sample seed data
const INITIAL_TODOS = [
  { id: 1, text: 'Set up Vite + React project', completed: true,  priority: 'high'   },
  { id: 2, text: 'Build Header component',       completed: true,  priority: 'medium' },
  { id: 3, text: 'Implement add & delete tasks', completed: false, priority: 'high'   },
  { id: 4, text: 'Style with custom CSS',        completed: false, priority: 'medium' },
  { id: 5, text: 'Write README and push to Git', completed: false, priority: 'low'    },
]

function App() {
  const [todos, setTodos] = useState(INITIAL_TODOS)

  // Add a new todo
  const handleAdd = (text, priority) => {
    const newTodo = {
      id: Date.now(),
      text,
      priority,
      completed: false,
    }
    setTodos(prev => [newTodo, ...prev])
  }

  // Toggle completed state
  const handleToggle = (id) => {
    setTodos(prev =>
      prev.map(t => t.id === id ? { ...t, completed: !t.completed } : t)
    )
  }

  // Delete a todo
  const handleDelete = (id) => {
    setTodos(prev => prev.filter(t => t.id !== id))
  }

  // Edit todo text
  const handleEdit = (id, newText) => {
    setTodos(prev =>
      prev.map(t => t.id === id ? { ...t, text: newText } : t)
    )
  }

  const completed = todos.filter(t => t.completed).length
  const pending   = todos.filter(t => !t.completed).length
  const progress  = todos.length > 0 ? Math.round((completed / todos.length) * 100) : 0

  return (
    <div className="app">
      <div className="app__container">
        <Header total={todos.length} completed={completed} pending={pending} />

        {/* Progress Bar */}
        {todos.length > 0 && (
          <div className="progress-wrap">
            <div className="progress-label">
              <span>Progress</span>
              <strong>{progress}%</strong>
            </div>
            <div className="progress-track">
              <div className="progress-bar" style={{ width: `${progress}%` }} />
            </div>
          </div>
        )}

        {/* Section Header */}
        <div className="section-header">
          <span className="section-title">Tasks</span>
        </div>

        {/* Main List */}
        <ToDoList
          todos={todos}
          onAdd={handleAdd}
          onToggle={handleToggle}
          onDelete={handleDelete}
          onEdit={handleEdit}
        />
      </div>
    </div>
  )
}

export default App
