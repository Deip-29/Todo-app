# DoIt — React To-Do App

A modern, beautifully designed To-Do List application built with **React + Vite**.

## ✨ Features

- ➕ **Add tasks** with priority levels (Low / Medium / High)
- ✅ **Mark tasks** as complete/incomplete
- ✏️ **Edit tasks** inline (click edit icon or press Enter to save, Escape to cancel)
- 🗑️ **Delete tasks** individually or clear all completed at once
- 🔍 **Filter** tasks by All / Active / Completed
- 📊 **Progress bar** showing overall completion
- 🎨 Unique dark-themed UI with animated micro-interactions

## 📁 Project Structure

```
todo-app/
├── index.html
├── vite.config.js
├── package.json
└── src/
    ├── main.jsx
    ├── App.jsx
    ├── components/
    │   ├── Header.jsx
    │   ├── ToDoList.jsx
    │   └── ToDoItem.jsx
    └── styles/
        ├── index.css
        ├── App.css
        ├── Header.css
        ├── ToDoList.css
        └── ToDoItem.css
```

## 🚀 Getting Started

### Prerequisites
- Node.js (v18 or higher)
- npm

### Installation

```bash
# 1. Clone the repository
git clone https://github.com/YOUR_USERNAME/todo-app.git

# 2. Navigate to the project directory
cd todo-app

# 3. Install dependencies
npm install

# 4. Start the development server
npm run dev
```

Open [http://localhost:5173](http://localhost:5173) in your browser.

### Build for Production

```bash
npm run build
```

## 🛠️ Tech Stack

- **React 18** — UI library
- **Vite 5** — Build tool
- **CSS Custom Properties** — Design tokens & theming
- **Google Fonts** — Syne + DM Sans typography

## 📚 Components

| Component | Description |
|-----------|-------------|
| `App` | Root component, holds all state |
| `Header` | Displays app title and stats |
| `ToDoList` | Add-task form, filters, renders list |
| `ToDoItem` | Individual task with toggle/edit/delete |

## 🎯 Assignment Checklist

- [x] Vite project setup
- [x] Functional components (App, Header, ToDoList, ToDoItem)
- [x] State management with `useState`
- [x] Props passed between components
- [x] Dynamic list rendering with `map` and unique keys
- [x] Add task event handling
- [x] Toggle complete event handling
- [x] Delete task event handling
- [x] Edit task event handling
- [x] CSS styling with custom design system
